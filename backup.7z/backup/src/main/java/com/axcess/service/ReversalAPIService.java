package com.axcess.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.axcess.model.ReversalAPIRequest;
import com.axcess.repository.ReversalAPIRepository;


@Service
public class ReversalAPIService {
	
	@Autowired
	ReversalAPIRepository reversalAPIRepository;
	
	public List<ReversalAPIRequest> findByid(String txnId){
		
		List <ReversalAPIRequest> txnDtls=reversalAPIRepository.findByid(txnId);
		
		return txnDtls;
	}
	
	public int revTxn(String txnId, String revReasonCode){
		int n=0;
		n=reversalAPIRepository.reverseTxn(txnId,revReasonCode);
		return n;
	}
	
	
	
	
}
