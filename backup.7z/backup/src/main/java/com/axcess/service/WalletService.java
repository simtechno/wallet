package com.axcess.service;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.axcess.model.AddpointsRequest;
import com.axcess.model.TransactionData;
import com.axcess.model.UserPoints;
import com.axcess.repository.GetBalanceRepository;

@Service
public class WalletService {

	@Autowired
	GetBalanceRepository getBalanceRepository;
	
	public List<UserPoints> findById(String bankid) {
		System.out.println(bankid);
		List<UserPoints> up = new ArrayList<UserPoints>();
		List<UserPoints> userPoints=getBalanceRepository.findyByid(bankid);
		for (UserPoints usrPoints: userPoints) {
			System.out.println(bankid);
			up.add(usrPoints);
		}
		System.out.println(up.size());
		return up;
	}
	
	public int getBalance(String bankid) {
		int total=0;
		List<UserPoints> userPoints=getBalanceRepository.findyByid(bankid);
		for (UserPoints usrPoints: userPoints) {
			total=total+usrPoints.getPoints().intValue();
		}
		return total;
	}
	
	public TreeMap<String, Integer> getChannelWiseBalance(String bankid) {
		TreeMap <String,Integer> pointsBal=new TreeMap<String, Integer>();
		
		List<UserPoints> userPoints=getBalanceRepository.findyByid(bankid);
		for (UserPoints usrPoints: userPoints) {
			pointsBal.put(usrPoints.getId().getChannel(),usrPoints.getPoints().intValue());
		}
		return pointsBal;
	}

	public int addPoints(AddpointsRequest request) {
		System.out.println("inside userid"+request.getBankid());
		int status= getBalanceRepository.addPoints(request.getBankid(), request.getPoints(), request.getChannel());
		
		return status;
	}
	
	
public List<TransactionData> loadTransactions(String bankid) {
		
		List<TransactionData> userPoints=getBalanceRepository.loadTransactions(bankid);
		return userPoints;
	}
	
	
}
