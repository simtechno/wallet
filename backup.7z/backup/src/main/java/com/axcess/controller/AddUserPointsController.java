package com.axcess.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.axcess.model.AddpointsRequest;
import com.axcess.model.TransactionData;
import com.axcess.model.UserPoints;
import com.axcess.service.WalletService;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
@Controller
public class AddUserPointsController {
	
	@Autowired
	WalletService walletService;
	
	
	@PostMapping(path="/addpoints",consumes="application/json", produces="application/json")
	@ResponseBody
	public String addPoints(@RequestBody JsonArray userpoints) {
	
		Gson g = new Gson();
				if(null != userpoints && userpoints.size() > 0){
			for(int i=0;i<userpoints.size();i++){
				AddpointsRequest addpointsRequest = g.fromJson(userpoints.getAsJsonArray().get(i), AddpointsRequest.class);
				System.out.println("addpointsRequest"+addpointsRequest.getBankid());
				int stataus = walletService.addPoints(addpointsRequest);
				System.out.println("stataus"+stataus);
			}
			//load purchase data and send it with response
			
			
		}
		
		//walletService.addPoints(request);
		return "response";
	}
	
	@PostMapping(path="/userpoints",consumes="application/json", produces="application/json")
	@ResponseBody
	public List<UserPoints> userPoints(@RequestBody String userId) {
		System.out.println("userId"+userId);
		List<UserPoints> userPoints=walletService.findById(userId);
		System.out.println("userPoints"+userPoints.size());
		return userPoints;
	}
	
	@PostMapping(path="/transferHistory",consumes="application/json", produces="application/json")
	@ResponseBody
	public List<TransactionData> transferHistory(@RequestBody String userId) {
		List<TransactionData> transactions=walletService.loadTransactions(userId);
		System.out.println("transactions"+transactions.size());
		return transactions;
	}
}
