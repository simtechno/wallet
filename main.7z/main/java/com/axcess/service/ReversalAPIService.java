package com.axcess.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.axcess.model.ReversalAPIRequest;
import com.axcess.repository.Modifying;
import com.axcess.repository.Param;
import com.axcess.repository.Query;
import com.axcess.repository.ReversalAPIRepository;
import com.axcess.repository.Transactional;


@Service
public class ReversalAPIService {
	
	@Autowired
	ReversalAPIRepository reversalAPIRepository;
	
	public List<ReversalAPIRequest> findByid(String txnId){
		
		List <ReversalAPIRequest> txnDtls=reversalAPIRepository.findByid(txnId);
		
		return txnDtls;
	}
	
	public int revTxn(String txnId, String revReasonCode){
		int n=0;
		n=reversalAPIRepository.reverseTxn(txnId,revReasonCode);
		return n;
	}
	
	/// write in get balace service
	@Transactional 
	public int revUserPoints(String bankId, int points, String channel){
		int c=0;
		c=getBalanceRepositiry.reverserPoints(bankId,points,channel);
		
		return c;
	}
	
	//get balance repo
	
	@Modifying
	@Query(value="insert into USER_POINTS (bankId,points,channel) values (:bankid,:points,:channel)",nativeQuery=true)
	@Transactional
	int reversePoints(@Param("bankid") String bankId, @Param("points") int points, @Param ("channel") String channel);

}
