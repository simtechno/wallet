package com.axcess.model;

import java.io.Serializable;

@Entity
@Table(name="TRANSACTION_DATA")
@NamesQuery(name="ReversalAPIRequest.findAll",query="Select u from ReversalAPIRequest u")
public class ReversalAPIRequest implements Serializable{
	
	public static final long serivalVersionUID=1L;
	
	@Id
	private String txnid;
	private int bankid;
	private String amount;
	private String machineid;
	private String status;
	private String revcode;
	public String getTxnid() {
		return txnid;
	}
	public void setTxnid(String txnid) {
		this.txnid = txnid;
	}
	public int getBankid() {
		return bankid;
	}
	public void setBankid(int bankid) {
		this.bankid = bankid;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getMachineid() {
		return machineid;
	}
	public void setMachineid(String machineid) {
		this.machineid = machineid;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRevcode() {
		return revcode;
	}
	public void setRevcode(String revcode) {
		this.revcode = revcode;
	}
	
	

}
