package com.axcess.repository;

import java.util.List;

import com.axcess.model.ReversalAPIRequest;

@Repository
	
	public interface ReversalAPIRepository extends JpaRepository <ReversalAPIRequest ,String> {
		
		@Query (value="Select u from ReversalAPIRequest u where u.id.txnid=:txnid")
		List<ReversalAPIRequest> findByid(@Param("txnid") String transactionId);
		
		@Modifying
		@Query(value="update TRANSACTION_DATA set status='REVERSED' , revcode=:revReasonCode where txnid=:txnid",nativeQuery=true)
		@Transactional
		int reverseTxn(@Param("txnid") String txnId, @Param("revReasonCode") String revResCode);

}
