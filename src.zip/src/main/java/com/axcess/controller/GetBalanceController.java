package com.axcess.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.axcess.service.WalletService;
@Controller
public class GetBalanceController {
	
	@Autowired
	WalletService walletService;
	
	
	@GetMapping("/balance")
	@ResponseBody
	public int getBalance(@RequestParam(name="UserId",required=true) String userId) {
		int totalPoints=walletService.getBalance(userId);
		return totalPoints;
	}
}
