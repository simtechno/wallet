package com.axcess.controller;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.axcess.model.ReversalAPIRequest;
import com.axcess.model.TransactionDataRequest;
import com.axcess.model.TransactionDataResponse;
import com.axcess.model.UserPoints;
import com.axcess.service.GetBalanceService;
import com.axcess.service.PurchaseAPIService;
import com.axcess.service.ReversalAPIService;
import com.axcess.service.WalletService;
import com.google.gson.Gson;

@RestController("wallet")
public class TxnController {

	@Autowired
	ReversalAPIService reversalAPIService;

	@Autowired
	GetBalanceService getBalanceService;

	@Autowired
	PurchaseAPIService purchaseAPIService;

	@Autowired
	WalletService walletService;

	// @PostMapping //(path = "/txn")
	// @ResponseBody
	// public String postTransaction(@RequestParam(name = "UserId", required =
	// false) String userId,
	// @RequestParam(name = "ProductId", required = false) String productId,
	// @RequestParam(name = "price", required = false) Integer price) {

	@PostMapping(consumes="application/json", produces="application/json")
	@ResponseBody
	public ResponseEntity postTransaction(@RequestBody TransactionDataRequest txnData) {
		
		
		String transactionId=null;
		
			System.out.println("post txn");

			String userId = txnData.getUserId();
			int userPoints = walletService.getBalance(userId);
			System.out.println("userPoints" + userPoints);
			int amount = txnData.getAmount();
			if (userPoints >= amount) {
				transactionId = String.valueOf(System.currentTimeMillis());
				System.out.println("transactionId" + transactionId);
				int recCnt = purchaseAPIService.postTxn(transactionId, amount, userId, "SUCCESS");

				if (recCnt > 0) {

					TreeMap<String, Integer> pointsMap = walletService.getChannelWiseBalance(userId);

					System.out.println(" pointsMap avl " + pointsMap);

					int pointsDeducted = 0;
					int pointsToBeDeducted = amount;

					int points = null!=pointsMap && pointsMap.get("REVERSAL")!=null?pointsMap.get("REVERSAL"):0;
					if (points > 0) {

						if (points < amount) {
							System.out.println(" points avl " + points + " | " + amount);
							pointsDeducted = pointsDeducted + points;

							pointsToBeDeducted = pointsToBeDeducted - points;
							int up = getBalanceService.adjustPoints(userId, 0, "REVERSAL");
						} else {
							pointsToBeDeducted = pointsToBeDeducted - amount;
							pointsDeducted = pointsDeducted + amount;

							int up = getBalanceService.adjustPoints(userId, points - amount, "REVERSAL");
						}
						System.out.println("deducted from REVERSAL");
						pointsMap.remove("REVERSAL");
					}

					System.out.println(" pointsMap avl " + pointsMap);
					pointsToBeDeducted = pointsToBeDeducted - pointsDeducted;

					if (pointsDeducted < amount) {

						Iterator<String> itr = pointsMap.keySet().iterator();

						while (itr.hasNext()) {
							String channel = itr.next();
							System.out.println("points deducted so far " + pointsDeducted + " | " + pointsToBeDeducted);
							System.out.println("Checking  from channel : " + channel);

							int pointFrmChnl = pointsMap.get(channel);
							System.out.println(pointFrmChnl + " points in: " + channel);
							if (pointFrmChnl > 0) {
								if (pointFrmChnl <= pointsToBeDeducted) {

									pointsDeducted = pointsDeducted + pointFrmChnl;
									pointsToBeDeducted = pointsToBeDeducted - pointFrmChnl;

									int up = getBalanceService.adjustPoints(userId, 0, channel);
									System.out.println("deducted all from " + channel);

								} else {
									int pointsReq = pointFrmChnl - pointsToBeDeducted;
									pointsDeducted = pointsDeducted + pointsToBeDeducted;
									pointsToBeDeducted = pointsToBeDeducted - pointsToBeDeducted;

									int up = getBalanceService.adjustPoints(userId, pointsReq, channel);
									System.out.println("deducted from " + channel);
								}
							}

							if (pointsToBeDeducted == 0) {
								System.out.println("got suffiient points " + pointsDeducted + " | " + amount);
								break;
							}

						}
					}


				}

			} else {
				//String transactionId = String.valueOf(System.currentTimeMillis());
				//int recCnt = purchaseAPIService.postTxn(transactionId, amount, userId, "FAILED");
				//response = "400&InSufficientBalance&transactionId=" + transactionId;
				
				
				
			}
			
			if (null!=transactionId){
				TransactionDataResponse txnDataRes=new TransactionDataResponse();
				
				txnDataRes.setTxnId(transactionId);
				
				Gson g = new Gson();
				return new ResponseEntity(g.toJson(txnDataRes), HttpStatus.OK);

			}else{
				
				Map<String,String> result =new HashMap<String,String>();
				result.put("message", "Insufficient Balance");
		        return new ResponseEntity(result, HttpStatus.BAD_REQUEST);

				
			}

		
	}

	@RequestMapping(method = RequestMethod.PATCH,consumes="application/json", produces="application/json")
	public ResponseEntity reverseTransaction(@RequestBody TransactionDataRequest txnData) {

		String resMsg = "FAILED";
		System.out.println("reverse txn");

		String txnId=txnData.getTxnId();
		
		System.out.println("reverse txn"+txnId);

		
		if (null!=txnId){
		
		List<ReversalAPIRequest> txnDtl = reversalAPIService.findByid(txnId);

		if (null != txnDtl && txnDtl.size() > 0) {

			String status = String.valueOf(txnDtl.get(0).getStatus());

			if (status != null && status.equalsIgnoreCase("SUCCESS")) {

				int recCnt = 0;

				String bankId = String.valueOf(txnDtl.get(0).getBankid());
				int points = Integer.parseInt(txnDtl.get(0).getAmount());

				List<UserPoints> revBalList = getBalanceService.getRevPointsBal(bankId);

				if (revBalList.size() > 0) {

					int revPointsBal = revBalList.get(0).getPoints().intValue();

					System.out.println("revPointsBal" + revPointsBal);
					recCnt = getBalanceService.reversePointsByUpdate(bankId, revPointsBal + points, "REVERSAL");
					System.out.println("Reverting user points by update");
				} else {
					recCnt = getBalanceService.revUserPoints(bankId, points, "REVERSAL");
				}

				if (recCnt > 0) {

					int updtCnt = reversalAPIService.revTxn(txnId, "300"); // 300
																			// is
																			// rev
																			// reason
																			// code

					if (updtCnt > 0) {
						resMsg = "SUCCESS";
					}

				}

			}

		}
		
		}

		if (resMsg.equalsIgnoreCase("SUCCESS")){
			TransactionDataResponse txnDataRes=new TransactionDataResponse();
			
			txnDataRes.setTxnId(txnId);
			
			Gson g = new Gson();
			
			return new ResponseEntity(g.toJson(txnDataRes), HttpStatus.OK);
		}else{
			Map<String,String> result =new HashMap<String,String>();
			result.put("message", "Could not reverse transaction");
			
			return new ResponseEntity(result, HttpStatus.BAD_REQUEST);
		}

	}

	@GetMapping // ("/balance")
	@ResponseBody
	public Map<String,String> getBalance(@RequestParam(name = "userId", required = true) String userId) {
		System.out.println("get balance");
		int totalPoints = walletService.getBalance(userId);
		
		Map<String,String> result =new HashMap<String,String>();
		result.put("points", String.valueOf(totalPoints));
		
		return result;
	}

}
