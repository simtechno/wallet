package com.axcess.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.axcess.model.UserPoints;
import com.axcess.repository.GetBalanceRepository;

@Service
public class GetBalanceService {

	@Autowired
	GetBalanceRepository getBalanceRepositiry;

	public List<UserPoints> getUserPoints(String bankId) {

		List<UserPoints> points = new ArrayList<>();

		points = getBalanceRepositiry.findyByid(bankId);

		return points;

	}
	
	public List<UserPoints> getRevPointsBal(String bankId) {
		

		List<UserPoints> list = new ArrayList<>();

		list = getBalanceRepositiry.reversalBalance(bankId);
		
System.out.println("list"+list);
		return list;

	}

	@Transactional
	public int revUserPoints(String bankId, int points, String channel) {
		int c = 0;
		c = getBalanceRepositiry.reversePoints(bankId, points, channel);

		return c;
	}
	
	@Transactional
	public int reversePointsByUpdate(String bankId, int points, String channel) {
		int c = 0;
		c = getBalanceRepositiry.reversePointsByUpdate(bankId, points, channel);

		return c;
	}
	
	@Transactional
	public int adjustPoints(String bankId, int points, String channel) {
		int c = 0;
		c = getBalanceRepositiry.adjustPoints(bankId, points, channel);

		return c;
	}


}
