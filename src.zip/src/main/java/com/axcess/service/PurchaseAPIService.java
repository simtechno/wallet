package com.axcess.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.axcess.repository.PurchaseAPIRepository;

@Service
public class PurchaseAPIService {
	
	@Autowired
	PurchaseAPIRepository purchaseAPIRepository;
	
	@Transactional
	
	public int postTxn(String txnId, int amount,String bankid,String status){
		
		int recCnt=purchaseAPIRepository.postTxn(txnId, amount, bankid, status);
		return recCnt;
		
	}

}
