package com.axcess.model;

public class TransactionDataRequest {
	
	private String txnId;
	private int amount;
	private String userId;
	private String status;
	private String revcode;
	public String getTxnId() {
		return txnId;
	}
	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRevcode() {
		return revcode;
	}
	public void setRevcode(String revcode) {
		this.revcode = revcode;
	}
	
	
	

}
