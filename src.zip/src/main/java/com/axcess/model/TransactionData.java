package com.axcess.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="TRANSACTION_DATA")
@NamedQuery(name="TransactionData.findAll", query="SELECT t FROM TransactionData t")
public class TransactionData implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	private String txnid;
	private String amount;
	private BigDecimal bankid;
	private String status;
	private BigDecimal productid;
	
	public TransactionData(){
		
	}

	public String getTxnid() {
		return txnid;
	}

	public void setTxnid(String txnid) {
		this.txnid = txnid;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public BigDecimal getBankid() {
		return bankid;
	}

	public void setBankid(BigDecimal bankid) {
		this.bankid = bankid;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public BigDecimal getProductid() {
		return productid;
	}

	public void setProductid(BigDecimal productid) {
		this.productid = productid;
	}

	
	
}
