package com.axcess.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


@Entity
@Table(name="TRANSACTION_DATA")
@NamedQuery(name="ReversalAPIRequest.findAll",query="Select u from ReversalAPIRequest u")
public class ReversalAPIRequest implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	@javax.persistence.Id
	private String txnid;
	private String bankid;
	private String amount;
	private String status;
	private String revcode;
	public String getTxnid() {
		return txnid;
	}
	public void setTxnid(String txnid) {
		this.txnid = txnid;
	}
	public String getBankid() {
		return bankid;
	}
	public void setBankid(String bankid) {
		this.bankid = bankid;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRevcode() {
		return revcode;
	}
	public void setRevcode(String revcode) {
		this.revcode = revcode;
	}
	
	

}
