package com.axcess.model;

public class TransactionDataResponse {
	
	private String txnId;
	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}

	private String message;
	
	public String getTxnId() {
		return txnId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	
	
	

}
