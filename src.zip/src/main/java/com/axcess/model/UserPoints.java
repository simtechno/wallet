package com.axcess.model;

import java.math.BigDecimal;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="USER_POINTS")
@NamedQuery (name="UserPoints.findAll",query="SELECT u FROM UserPoints u")


public class UserPoints {
	
	@EmbeddedId
	private UserPointsPK id;
	private BigDecimal points;
	
	public UserPointsPK getId() {
		return id;
	}
	public void setId(UserPointsPK id) {
		this.id = id;
	}
	public BigDecimal getPoints() {
		return points;
	}
	public void setPoints(BigDecimal points) {
		this.points = points;
	}
	
	public UserPoints() {
		
	}
	
	@Override
	public String toString() {
		return "UserPoints [BankId=" +id.getBankid() + ",Channel="+id.getChannel()+ ",points="+points+"]";
		
	}
	
}
