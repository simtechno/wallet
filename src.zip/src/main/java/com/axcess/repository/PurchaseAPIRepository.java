package com.axcess.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.axcess.model.ReversalAPIRequest;

@Repository
	
	public interface PurchaseAPIRepository extends JpaRepository <ReversalAPIRequest ,String> {
		
	@Modifying
	@Query(value="insert into TRANSACTION_DATA (txnid,amount,bankid,status) values (:txnid,:amount,:bankid,:status)",nativeQuery=true)
	@Transactional
	int postTxn(@Param("txnid") String txnId, @Param("amount") int amount, @Param ("bankid") String bankid,@Param ("status") String Status);

		

}
