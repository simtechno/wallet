package com.axcess.model;

import java.io.Serializable;

public class UserPointsPK implements Serializable{
	private static final long serialVersionUID=1L;
	private String bankid;
	private String channel;
	
	public UserPointsPK() {
		
	}
	public String getBankid() {
		return bankid;
	}
	public void setBankid(String bankid) {
		this.bankid = bankid;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	

}
