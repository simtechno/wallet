package com.axcess.controller;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.TreeMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.axcess.model.ReversalAPIRequest;
import com.axcess.model.UserPoints;
import com.axcess.service.GetBalanceService;
import com.axcess.service.PurchaseAPIService;
import com.axcess.service.ReversalAPIService;
import com.axcess.service.WalletService;
import com.fasterxml.jackson.annotation.JacksonInject.Value;

@Controller
public class TxnController {

	@Autowired
	ReversalAPIService reversalAPIService;

	@Autowired
	GetBalanceService getBalanceService;

	@Autowired
	PurchaseAPIService purchaseAPIService;

	@Autowired
	WalletService walletService;

	@PostMapping(path = "/txn")
	@ResponseBody
	public String postTransaction(@RequestParam(name = "UserId", required = false) String userId,
			@RequestParam(name = "ProductId", required = false) String productId,
			@RequestParam(name = "price", required = false) Integer price,
			@RequestParam(name = "TxnId", required = false) String txnId,
			@RequestParam(name = "ReversalReasonCode", required = false) String reversalReasonCode,
			@RequestParam(name = "reverse", required = false) boolean reverse) {

		String response = "400";
		System.out.println("txn controller");
		if (reverse) {
			System.out.println("reverse txn");

			List<ReversalAPIRequest> txnDtl = reversalAPIService.findByid(txnId);

			if (null != txnDtl && txnDtl.size() > 0) {

				String status = String.valueOf(txnDtl.get(0).getStatus());

				if (status != null && status.equalsIgnoreCase("SUCCESS")) {

					int recCnt = 0;

					String bankId = String.valueOf(txnDtl.get(0).getBankid());
					int points = Integer.parseInt(txnDtl.get(0).getAmount());

					
					List<UserPoints> revBalList = getBalanceService.getRevPointsBal(bankId);


					if (revBalList.size()>0) {
						
						int revPointsBal=revBalList.get(0).getPoints().intValue();
						
						System.out.println("revPointsBal" + revPointsBal);
						recCnt = getBalanceService.reversePointsByUpdate(bankId, revPointsBal + points, "REVERSAL");
						System.out.println("Reverting user points by update");
					} else {
						recCnt = getBalanceService.revUserPoints(bankId, points, "REVERSAL");
					}

					if (recCnt > 0) {

						int updtCnt = reversalAPIService.revTxn(txnId, reversalReasonCode);

						if (updtCnt > 0) {
							response = "200";
						}

					}

				}

			}
		} else {
			System.out.println("post txn");

			int userPoints = walletService.getBalance(userId);
			System.out.println("userPoints" + userPoints);
			if (userPoints >= price) {
				String transactionId = String.valueOf(System.currentTimeMillis());
				int recCnt = purchaseAPIService.postTxn(transactionId, price, userId, "SUCCESS");

				if (recCnt > 0) {

					TreeMap<String, Integer> pointsMap = walletService.getChannelWiseBalance(userId);

					System.out.println(" pointsMap avl " + pointsMap);

					int pointsDeducted = 0;
					int pointsToBeDeducted = price;

					int points = pointsMap.get("REVERSAL");
					if (points > 0) {

						if (points < price) {
							System.out.println(" points avl " + points + " | " + price);
							pointsDeducted = pointsDeducted + points;

							pointsToBeDeducted = pointsToBeDeducted - points;
							int up = getBalanceService.adjustPoints(userId, 0, "REVERSAL");
						} else {
							pointsToBeDeducted = pointsToBeDeducted - price;
							pointsDeducted = pointsDeducted + price;

							int up = getBalanceService.adjustPoints(userId, points - price, "REVERSAL");
						}
						System.out.println("deducted from REVERSAL");
						pointsMap.remove("REVERSAL");
					}

					System.out.println(" pointsMap avl " + pointsMap);
					pointsToBeDeducted = pointsToBeDeducted - pointsDeducted;

					if (pointsDeducted < price) {

						Iterator<String> itr = pointsMap.keySet().iterator();

						while (itr.hasNext()) {
							String channel = itr.next();
							System.out.println("points deducted so far " + pointsDeducted + " | " + pointsToBeDeducted);
							System.out.println("Checking  from channel : " + channel);

							int pointFrmChnl = pointsMap.get(channel);
							System.out.println(pointFrmChnl + " points in: " + channel);
							if (pointFrmChnl > 0) {
								if (pointFrmChnl <= pointsToBeDeducted) {

									pointsDeducted = pointsDeducted + pointFrmChnl;
									pointsToBeDeducted = pointsToBeDeducted - pointFrmChnl;

									int up = getBalanceService.adjustPoints(userId, 0, channel);
									System.out.println("deducted all from " + channel);

								} else {
									int pointsReq = pointFrmChnl - pointsToBeDeducted;
									pointsDeducted = pointsDeducted + pointsToBeDeducted;
									pointsToBeDeducted = pointsToBeDeducted - pointsToBeDeducted;

									int up = getBalanceService.adjustPoints(userId, pointsReq, channel);
									System.out.println("deducted from " + channel);
								}
							}

							if (pointsToBeDeducted == 0) {
								System.out.println("got suffiient points " + pointsDeducted + " | " + price);
								break;
							}

						}
					}

					/*
					 * while (pointsToDeduct<=price){
					 * 
					 * int points=pointsMap.get("REVERSAL"); if (points>0){
					 * pointsToDeduct=pointsToDeduct+points; }else{
					 * Iterator<String> itr=pointsMap.keySet().iterator();
					 * 
					 * String channel=itr.next();
					 * 
					 * int pointsFor=pointsMap.get(channel); if (pointsFor>0){
					 * pointsToDeduct=pointsToDeduct+pointsFor; }
					 * 
					 * 
					 * }
					 * 
					 * 
					 * }
					 */

					response = "200&transactionId=" + transactionId;

				}

			} else {
				String transactionId = String.valueOf(System.currentTimeMillis());
				int recCnt = purchaseAPIService.postTxn(transactionId, price, userId, "FAILED");
				response = "400&InSufficientBalance&transactionId=" + transactionId;
			}

		}
		return response;

	}

}
