package com.axcess.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.axcess.Model.AddpointsRequest;
import com.axcess.Model.TransactionData;
import com.axcess.Model.UserPoints;
import com.axcess.repository.GetBalanceRepository;

@Service
public class WalletService {

	@Autowired
	GetBalanceRepository getBalanceRepository;
	
	public List<UserPoints> findById(String bankid) {
		System.out.println(bankid);
		List<UserPoints> up = new ArrayList<UserPoints>();
		List<UserPoints> userPoints=getBalanceRepository.findyByid(bankid);
		for (UserPoints usrPoints: userPoints) {
			System.out.println(bankid);
			up.add(usrPoints);
		}
		System.out.println(up.size());
		return up;
	}
	
	public int getBalance(String bankid) {
		int total=0;
		List<UserPoints> userPoints=getBalanceRepository.findyByid(bankid);
		for (UserPoints usrPoints: userPoints) {
			total=total+usrPoints.getPoints().intValue();
		}
		return total;
	}
	

	public int addPoints(AddpointsRequest request) {
		System.out.println("inside userid"+request.getUserId());
		int status= getBalanceRepository.addPoints(request.getUserId(), request.getPoints(), request.getChannel());
		
		return status;
	}
	
	
public List<TransactionData> loadTransactions(String bankid) {
		
		List<TransactionData> userPoints=getBalanceRepository.loadTransactions(bankid);
		return userPoints;
	}
	
	
}
