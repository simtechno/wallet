package com.axcess.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.axcess.Model.AddpointsRequest;
import com.axcess.repository.GetBalanceRepository;

@Service
public class UserPointsService {

	@Autowired
	GetBalanceRepository getBalanceRepository;
	
	
	
	public int addPoints(AddpointsRequest request) {
		
		int status= getBalanceRepository.addPoints(request.getUserId(), request.getPoints(), request.getChannel());
		
		return status;
	}
	
	
	
}
