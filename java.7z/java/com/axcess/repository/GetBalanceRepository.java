package com.axcess.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.axcess.Model.TransactionData;
import com.axcess.Model.UserPoints;

@Repository
public interface GetBalanceRepository extends JpaRepository <UserPoints,String> {
	
	@Query(value="SELECT u FROM UserPoints u where u.id.bankid=:bankid")
	List<UserPoints> findyByid(@Param("bankid") String bankid);
	
	@Modifying
	@Query(value="Insert into USER_POINTS (bankid,points,channel) values (:bankid,:points,:channel)",nativeQuery=true)
	@Transactional
	void reverserPoints(@Param("bankid") String insertLink,@Param("points") int points,@Param("channel") String Channel);
	
	@Modifying
	@Query(value="Insert into USER_POINTS (bankid,points,channel) values (:bankid,:points,:channel)",nativeQuery=true)
	public int addPoints(@Param("bankid") String insertLink,@Param("points") int points,@Param("channel") String Channel);
	
	@Query(value="SELECT u FROM TransactionData u where u.id.bankid=:bankid")
	List<TransactionData> loadTransactions(@Param("bankid") String bankid);
	
}
